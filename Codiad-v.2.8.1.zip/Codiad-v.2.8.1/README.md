# Codiad Web IDE

Codiad is a web-based IDE framework with a small footprint and minimal requirements. 

Codiad was built with simplicity in mind, allowing for fast, interactive development without the massive overhead of some of the larger desktop editors. That being said even users of IDE's such as Eclipse, NetBeans and Aptana are finding Codiad's simplicity to be a huge benefit. While simplicity was key, we didn't skimp on features and have a team of dedicated developer actively adding more.

Keep up to date with the latest changes and news on **[Twitter](http://twitter.com/codiadide)** or **[Facebook](http://www.facebook.com/Codiad)**

For more information on the project please check out the **[check out the Wiki](https://github.com/Codiad/Codiad/wiki)** or **[the Codiad Website](http://www.codiad.com)**

Distributed under the MIT-Style License. See `LICENSE.txt` file for more information.
