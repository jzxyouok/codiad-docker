# Plugins

The plugins directory is where you place plugins :-)

[GET SOME...](http://market.codiad.com/)
